const form = document.getElementById("loginForm");
const msg = document.getElementById("msg");

// Usuario y contraseña simulados
const USER = "admin";
const PASS = "1234";

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const user = document.getElementById("user").value;
  const password = document.getElementById("password").value;

  if (user === USER && password === PASS) {
    localStorage.setItem("login", "true");
    window.location.href = "index.html";
  } else {
    msg.textContent = "Usuario o contraseña incorrectos";
  }
});
