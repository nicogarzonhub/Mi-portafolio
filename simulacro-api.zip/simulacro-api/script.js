const API_USERS = "http://localhost:3000/users";
const API_POSTS = "http://localhost:3000/posts";

/* ================= LOGIN ================= */
const loginForm = document.getElementById("loginForm");

if (loginForm) {
  loginForm.addEventListener("submit", async e => {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const res = await fetch(`${API_USERS}?email=${email}&password=${password}`);
    const data = await res.json();

    if (data.length > 0) {
      localStorage.setItem("user", JSON.stringify(data[0]));
      window.location.href = "posts.html";
    } else {
      document.getElementById("error").textContent = "Credenciales incorrectas";
    }
  });
}

/* ================= PROTECCIÓN ================= */
if (window.location.pathname.includes("posts.html")) {
  if (!localStorage.getItem("user")) {
    window.location.href = "index.html";
  }
}

/* ================= CRUD POSTS ================= */
const postForm = document.getElementById("postForm");
const postsDiv = document.getElementById("posts");
const postId = document.getElementById("postId");

if (postForm) {
  postForm.addEventListener("submit", async e => {
    e.preventDefault();

    const post = {
      titulo: titulo.value,
      contenido: contenido.value
    };

    // CREAR
    if (postId.value === "") {
      await fetch(API_POSTS, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(post)
      });
    }
    // EDITAR
    else {
      await fetch(`${API_POSTS}/${postId.value}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(post)
      });
    }

    postForm.reset();
    postId.value = "";
    cargarPosts();
  });
}

/* ================= MOSTRAR POSTS ================= */
async function cargarPosts() {
  const res = await fetch(API_POSTS);
  const data = await res.json();

  postsDiv.innerHTML = "";

  data.forEach(post => {
    const card = document.createElement("div");
    card.className = "col-md-4 mb-3";

    card.innerHTML = `
      <div class="card shadow">
        <div class="card-body">
          <h5>${post.titulo}</h5>
          <p>${post.contenido}</p>

          <button class="btn btn-warning btn-sm btn-editar">
            Editar
          </button>

          <button class="btn btn-danger btn-sm btn-eliminar" data-id="${post.id}">
            Eliminar
          </button>
        </div>
      </div>
    `;

    // EDITAR
    card.querySelector(".btn-editar").addEventListener("click", () => {
      editar(post);
    });

    // ELIMINAR (AQUÍ ESTABA EL PROBLEMA)
    card.querySelector(".btn-eliminar").addEventListener("click", () => {
      eliminar(post.id);
    });

    postsDiv.appendChild(card);
  });
}


/* ================= EDITAR ================= */
function editar(post) {
  postId.value = post.id;
  document.getElementById("titulo").value = post.titulo;
  document.getElementById("contenido").value = post.contenido;
}

/* ================= ELIMINAR (100% OK) ================= */
async function eliminar(id) {
  if (!confirm("¿Seguro que deseas eliminar este post?")) return;

  await fetch(`${API_POSTS}/${id}`, {
    method: "DELETE"
  });

  cargarPosts();
}

/* ================= LOGOUT ================= */
function logout() {
  localStorage.removeItem("user");
  window.location.href = "index.html";
}

/* ================= INIT ================= */
if (postsDiv) cargarPosts();
