 const API_URL = "http://localhost:3000/users";

const signupForm = document.getElementById("signupForm");

signupForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("signupFullname").value.trim();
  const email = document.getElementById("signupEmail").value.trim();
  const password = document.getElementById("signupPassword").value.trim();

  try {
    // Verificar si el email ya existe
    const checkUser = await fetch(`${API_URL}?email=${email}`);
    const exists = await checkUser.json();

    if (exists.length > 0) {
      alert("Email already registered ");
      return;
    }

    const newUser = {
      name,
      email,
      password
    };

    await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newUser)
    });

    alert("Account created successfully ");
    window.location.href = "./login.html";

  } catch (error) {
    console.error(error);
    alert("Server error ");
  }
});