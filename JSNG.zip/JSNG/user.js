document.getElementById("toggleSidebar").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("collapsed");
});

/* navegación */
document.querySelectorAll(".menu-link").forEach(link => {
  link.addEventListener("click", () => {
    document.querySelectorAll(".menu-link").forEach(l => l.classList.remove("active"));
    link.classList.add("active");

    document.querySelectorAll(".page").forEach(p => p.classList.remove("active-page"));
    document.getElementById(link.dataset.page).classList.add("active-page");
  });
});

// =======================
// STORAGE
// =======================
function getTasks() {
  return JSON.parse(localStorage.getItem("tasks")) || [];
}

function saveTasks(tasks) {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}


// CREATE TASK (demo)

function createTask(user = "Sarah", total = "Completed") {
  const tasks = getTasks();

  tasks.push({
    id: Date.now(),
    user,
    date: new Date().toLocaleDateString(),
    status: "Pending",
    total
  });

  saveTasks(tasks);
  renderDashboard();
  renderMyTasks();
  updateStats();
}
