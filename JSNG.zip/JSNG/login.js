 const API_URL = "http://localhost:3000/users";

const loginForm = document.getElementById("loginForm");
const isLogged = localStorage.getItem("loggedUser");


loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("loginFullname").value.trim();
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value.trim();

  try {
    // Buscar usuario por email y password
    const response = await fetch(
      `${API_URL}?email=${email}&password=${password}`
    );
    const users = await response.json();

    if (users.length === 0) {
      alert("Invalid credentials ");
      return;
    }

    const user = users[0];

    // Validar nombre (extra por tu formulario)
    if (user.name !== name) {
      alert("Name does not match ");
      return;
    }

    // Guardar sesión
    localStorage.setItem("user", JSON.stringify(user));

    // Redirección por rol
    if (user.role === "admin") {
      window.location.href = "/admin.html";
    } else {
      window.location.href = "/dashboard.html";
    }

  } catch (error) {
    console.error(error);
    alert("Server error ");
  }
});