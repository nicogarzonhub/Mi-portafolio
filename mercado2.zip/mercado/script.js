const track = document.getElementById('carousel');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');

const cards = document.querySelectorAll('.card');
const visibleCards = 5;
let index = 0;

function updateCarousel() {
  const cardWidth = cards[0].offsetWidth + 20; // width + gap
  track.style.transform = `translateX(-${index * cardWidth}px)`;

  prevBtn.disabled = index === 0;
  nextBtn.disabled = index >= cards.length - visibleCards;
}

nextBtn.addEventListener('click', () => {
  if (index < cards.length - visibleCards) {
    index += visibleCards;
    updateCarousel();
  }
});

prevBtn.addEventListener('click', () => {
  if (index > 0) {
    index -= visibleCards;
    updateCarousel();
  }
});

window.addEventListener('resize', updateCarousel);

updateCarousel();
