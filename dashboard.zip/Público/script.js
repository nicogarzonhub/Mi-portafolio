let nameInput = document.getElementById("name");
let lastNameInput = document.getElementById("last_name");
let saveButton = document.getElementById("saveButton");
let name = ""; let lastName = ""; id = 0;
let editingRow = null;
let editingId = null;
const goodJob = document.createElement("div"); goodJob.classList.add("good-job");

function StoreIntable(id, name, last_name) {
    const tr = document.createElement("tr");

    tr.innerHTML = `
        <td>${id}</td>
        <td>${name}</td>
        <td>${last_name}</td>
        <td>
            <button class="details">Detalles</button>
            <button class="edit">Editar</button>
            <button class="delete">Eliminar</button>
        </td>
    `;

    // DETALLES
    tr.querySelector(".details").addEventListener("click", () => {
        Swal.fire({
            title: "Detalles del registro",
            html: `
                <p><strong>ID:</strong> ${id}</p>
                <p><strong>Nombre:</strong> ${name}</p>
                <p><strong>Apellido:</strong> ${last_name}</p>
            `,
            icon: "info",
            confirmButtonText: "Cerrar"
        });
    });

    // ELIMINAR
    tr.querySelector(".delete").addEventListener("click", () => {
        tr.remove();
    });

    // EDITAR
    tr.querySelector(".edit").addEventListener("click", () => {
        nameInput.value = name;
        lastNameInput.value = last_name;

        editingRow = tr;
        editingId = id;

        saveButton.textContent = "Actualizar";
    });

    return tr;
}



saveButton.addEventListener("click", () => {
    name = nameInput.value;
    lastName = lastNameInput.value;

    const table = document.querySelector("table tbody");

    if (name !== "" && lastName !== "") {

        if (editingRow) {
            // ACTUALIZAR
            editingRow.children[1].textContent = name;
            editingRow.children[2].textContent = lastName;

            editingRow = null;
            editingId = null;
            saveButton.textContent = "Guardar";

            Swal.fire({
                icon: "success",
                title: "Updated",
                text: "Data updated correctly",
            });

        } else {
            // GUARDAR NUEVO
            id++;
            table.appendChild(StoreIntable(id, name, lastName));

            Swal.fire({
                icon: "success",
                title: "Success",
                text: "Data saved correctly",
            });
        }

        nameInput.value = "";
        lastNameInput.value = "";

    } else {
        Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Name and Last Name are required",
        });
    }
});