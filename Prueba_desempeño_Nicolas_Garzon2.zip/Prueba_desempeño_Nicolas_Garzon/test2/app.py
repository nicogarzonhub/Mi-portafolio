import services

from typing import List, Dict

Product = Dict[str, object]
#validates for float
def request_float(prompt: str) -> float:
    while True:
        val = input(prompt)
        try:
            f = float(val)
            if f < 0:
                print("The value cannot be negative. Please try again.")
                continue
            return f
        except ValueError:
            print("Invalid entry. Please enter a valid number.")
#Validates for int
def request_int(prompt: str) -> int:
    while True:
        val = input(prompt)
        try:
            i = int(float(val))
            if i < 0:
                print("The value cannot be negative. Please try again.")
                continue
            return i
        except ValueError:
            print("Invalid entry. Please enter a valid number.")
# List of books
def main():
    inventory: List[Product] = [
        {"name": "1984", "author": "Orwell", "category": "Novel", "price": 50, "quantity": 2},
        {"name": "Lolita", "author": "Vladimir N", "category": "Novel", "price": 30, "quantity": 5},
        {"name": "Odisea", "author": "Homer", "category": "Poem", "price": 15, "quantity": 3},
        {"name": "Dracula", "author": "Bram S", "category": "Horror", "price": 25, "quantity": 5},
        {"name": "Hamlet", "author": "William S", "category": "Theatre", "price": 100, "quantity": 2},
    ]

# The menu of program
    while True:
        print("= MENU =")
        print("1. Add product")
        print("2. Show inventory")
        print("3. Search product")
        print("4. Update product")
        print("5. Remove product")
        print("6. Inventory statistics")
        print("7. Apply discount")
        print("8. Top 3")
        print("9. Leaving...")

        option = input("Choose an option (1-9): ").strip()
        if option not in [str(i) for i in range(1, 10)]:
            print("Invalid option. Choose a number between 1 and 9.\n")
            continue
            #Add the information for the menu
        try:
            if option == "1":
                name = input("Product name: ").strip()
                author = input("Author name: ").strip()
                category = input("Category: ").strip()
                price = request_float("Price: ")
                quantity = request_int("Quantity: ")

                services.add_product(inventory, name, author, category, price, quantity)
                print("Product added.\n")

            elif option == "2":
                services.show_inventory(inventory)

            elif option == "3":
                name = input("Name to search: ")
                p = services.search_product(inventory, name)
                if p:
                    print(f"Product found: {p['name']} — Price: ${p['price']:.2f} — Quantity: {p['quantity']}\n")
                else:
                    print("Product not found.\n")

            elif option == "4":
                name = input("Name of the product to update: ")
                if services.search_product(inventory, name) is None:
                    print("Product does not exist.\n")
                    continue

                answer = input("Change price? (Y/N): ").strip().lower()
                new_price = None
                if answer == "y":
                    new_price = request_float("New price: ")

                answer = input("Change quantity? (Y/N): ").strip().lower()
                new_quantity = None
                if answer == "y":
                    new_quantity = request_int("New quantity: ")

                updated = services.update_product(inventory, name, new_price, new_quantity)
                if updated:
                    print("Product updated.\n")
                else:
                    print("Update error (product not found).\n")

            elif option == "5":
                name = input("Product name to remove: ")
                removed = services.remove_product(inventory, name)
                if removed:
                    print("Product removed!\n")
                else:
                    print("Product not found.\n")

            elif option == "6":
                stats = services.calculate_statistics(inventory)
                print("\n- Statistics -")
                print(f"Total units: {stats['total_units']}")
                print(f"Total inventory value: ${stats['total_value']:,.2f}")
                pro = stats["most_expensive_product"]
                max = stats["highest_stock_product"]

                if pro:
                    print(f"Most expensive product: {pro['name']} (${pro['price']:.2f})")
                else:
                    print("Most expensive product: N/A")

                if max:
                    print(f"Product with highest stock: {max['name']} ({max['quantity']} units)")
                else:
                    print("Product with highest stock: N/A")

                print("-\n")
            
            elif option == "7":
                name= input("Ingrese el nombre del producto para descontar: ")
                price= input("Enter para continuar")
                services.apply_discount(inventory,name,price)
                
            
            elif option== "8":
                services.main()
            
            elif option=="9":
                print("Leaving..")
                break
            
        except Exception as e:
            print(f"Error: {e}\n")

# Run program
main()