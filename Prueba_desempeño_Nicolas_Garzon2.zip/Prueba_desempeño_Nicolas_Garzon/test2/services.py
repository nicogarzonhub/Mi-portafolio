"""
services.py
Functions to manage the inventory in memory (list of dictionaries).

Structure of each product:
{"name": str, "price": float, "quantity": int}
"""
from typing import List, Dict, Optional

Product = Dict[str, object]  # 'name', 'price', 'quantity'

def add_product(inventory: List[Product], name: str, author: str, category: str, price: float, quantity: int) -> None:
    
    name = name.strip()
    for p in inventory:
        if p["name"].lower() == name.lower():
            # Merge: add quantity and update price to the new one
            p["quantity"] += int(quantity)
            p["price"] = float(price)
            p["author"] = str(author)
            p["category"] = str(category)
            return
    inventory.append({"name": name, "author": author, "category": category, "price": float(price), "quantity": int(quantity)})


def show_inventory(inventory: List[Product]) -> None:
    """
    Shows the inventory in a readable console format.
    Parameters:
        inventory: list of products.
    Return: None
    """
    if not inventory:
        print("The inventory is empty.\n")
        return

    print("\n= INVENTORY =")
    for i, p in enumerate(inventory, start=1):
        print(f"{i}. {p['name']} — Author: {p['author']} — Category: {p['category']} — Price: ${p['price']:.2f} — Quantity: {p['quantity']}")
    print()

def search_product(inventory: List[Product], name: str) -> Optional[Product]:
    """
    Searches a product by name (case-insensitive).
    Parameters:
        inventory: list of products.
        name: name to search.
    Return:
        The dict of the product if found, or None if it does not exist.
    """
    name = name.strip()
    for p in inventory:
        if p["name"].lower() == name.lower():
            return p
    return None
def apply_discount(inventory: List[Product], name: str,price:float):
    name = name.strip().lower()
    price = price.strip().lower()
    # Buscar el producto
    for producto in inventory:
        if producto["name"].lower() == name:
            porcentaje = float(input("Porcentaje de descuento: "))

            descuento = producto["price"] * (porcentaje / 100)
            producto["price"] -= descuento

            print(f"Descuento aplicado. New price: {producto['price']}")
            return

    print("Producto no encontrado.")

def update_product(inventory: List[Product], name: str, new_price: Optional[float] = None, new_quantity: Optional[int] = None) -> bool:
    """
    Updates price and/or quantity of an existing product.
    Parameters:
        inventory: list of products.
        name: name of the product to update.
        new_price: new price (float) if you want to change it.
        new_quantity: new quantity (int) if you want to change it.
    Return:
        True if updated, False if the product does not exist.
    """
    p = search_product(inventory, name)
    if p is None:
        return False

    if new_price is not None:
        p["price"] = float(new_price)
    if new_quantity is not None:
        p["quantity"] = int(new_quantity)
    return True

def remove_product(inventory: List[Product], name: str) -> bool:
    """
    Removes a product from the inventory by name.
    Parameters:
        inventory: list of products.
        name: name of the product to remove.
    Return:
        True if removed, False if not found.
    """
    name = name.strip()
    for p in list(inventory):  # iterate over copy to safely remove
        if p["name"].lower() == name.lower():
            inventory.remove(p)
            return True
    return False

def main():
    """
    Removes a product from the inventory by name.
    Parameters:
        inventory: list of products.
        name: name of the product to remove.
    Return:
        True if removed, False if not found.
    """
    inventory: List[Product] = [
        {"name": "1984", "author": "Orwell", "category": "Novel", "price": 50, "quantity": 2},
        {"name": "Lolita", "author": "Vladimir N", "category": "Novel", "price": 30, "quantity": 5},
        {"name": "Odisea", "author": "Homer", "category": "Poem", "price": 15, "quantity": 3},
        {"name": "Dracula", "author": "Bram S", "category": "Horror", "price": 25, "quantity": 5},
        {"name": "Hamlet", "author": "William S", "category": "Theatre", "price": 100, "quantity": 2},
    ]

    # Order from highest to lowest price
    ordered_inventory = sorted(inventory, key=lambda p: p["price"], reverse=True)

    # Take top 3 most expensive
    top3 = ordered_inventory[:3]

    print("=== TOP 3 MOST EXPENSIVE PRODUCTS ===")
    for product in top3:
        print(f"{product['name']} - ${product['price']}")


def calculate_statistics(inventory: List[Product]) -> Dict[str, object]:
    """
    Computes inventory statistics:
      - total_units: sum of quantities
      - total_value: sum of price * quantity
      - most_expensive_product: dict {'name', 'price'}
      - highest_stock_product: dict {'name', 'quantity'}
    Parameters:
        inventory: list of products.
    Return:
        dict with metrics.
    Note: uses a lambda for optional subtotal.
    """
    if not inventory:
        return {
            "total_units": 0,
            "total_value": 0.0,
            "most_expensive_product": None,
            "highest_stock_product": None
        }

    subtotal = (lambda p: p["price"] * p["quantity"])  # lambda 

    total_units = sum(int(p["quantity"]) for p in inventory)
    total_value = sum(subtotal(p) for p in inventory)

    most_expensive = max(inventory, key=lambda p: p["price"])
    highest_stock = max(inventory, key=lambda p: p["quantity"])

    return {
        "total_units": total_units,
        "total_value": total_value,
        "most_expensive_product": {"name": most_expensive["name"], "price": most_expensive["price"]},
        "highest_stock_product": {"name": highest_stock["name"], "quantity": highest_stock["quantity"]}
    }

    